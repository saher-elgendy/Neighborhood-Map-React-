import React, { Component } from 'react';
import './App.css';
import MapDetails from './MapDetails';
import List from './List'
import escapeRegExp from 'escape-string-regexp'
import ErrorBoundary from 'react-error-boundary'

class App extends Component {
  state = {
    locations: [
      // static locations for testing so don't consume the api calls.
      // { name: 'Museium of Islamic Art', location: { lat: 30.04556, lng: 31.2533 }, details: 'A new resturant' },
      // { name: 'Pyramids of Giza', location: { lat: 29.976480, lng: 31.131302 }, details: 'A new resturant' },
      // { name: 'Cairo Tower', location: { lat: 30.045916, lng: 31.224291 }, details: 'A new resturant' },
      // { name: 'International Garden', location: { lat: 30.044281, lng: 31.340002 }, details: 'A new resturant' },
      // { name: 'Salah Eldin Citadel', location: { lat: 30.02433236, lng: 31.256832 }, details: 'A new resturant' }
    ],
    showingInfoWindow: false,
    activeMarker: {},
    selectedPlace: {},
    query: '',
    markerIcon: { url: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png' }
  }
  // fetching the locations from foursquare api and handle the auth error.
  componentDidMount() {
    fetch('https://api.foursquare.com/v2/venues/search?ll=30.04442,31.235712&intent=browse&radius=30000&query=restaurants&client_id=HLSZU3EPS5C5X1YX0HM5XQKDYDBQOSTNITC1WMRXXMHVUXL0&client_secret=NRI1UBZWJ4V1FJJHB0SQWISS2Z2QOLL2S3UQAB0513GQNFXP&v=201807029')
      .then(result => {
        return result.json()
      })
      .then(data => {
        let locations = data.response.venues
        this.setState({ locations: locations })
      })
      .catch(e => { alert('Error: ' + e) })

    window.gm_authFailure = this.gm_authFailure
    // Using this from MDN as the reviewer asked.
    window.addEventListener('unhandledrejection', function (event) {
      alert('App cannot reach Google servers due to firewall: ' + event.reason);
    })
  }

  // Authentication error message.
  gm_authFailure = () => {
    alert(`Google Maps Authentication Error!
           Please Check your API License Key`);
  };

  // Open infowindow on marker click.
  onMarkerClick = (props, marker) => {
    this.setState({
      selectedPlace: props,
      activeMarker: marker,
      showingInfoWindow: true,
    })
  }

  // handle the text typed in the input field.
  handleValueChange = (query) => {
    this.setState({ query: query })
  }

  // when the restaurant name is clicked on the list open the infowindow on it's marker.
  onListClick = (listName) => {
    let clickedMarker = [...document.querySelectorAll('.gmnoprint')]

    clickedMarker.find(marker => {
      if (marker.title === listName) {
        marker.click()
      }
    })

  }

  render() {
    let showPlaces;
    if (this.state.query) {
      const match = new RegExp(escapeRegExp(this.state.query), 'i')
      showPlaces = this.state.locations.filter(location => match.test(location.name))
    } else {
      showPlaces = this.state.locations
    }
    let toggle = () => {
      document.getElementById('sidelist').classList.toggle('open')
    }
    return (
      <div className="App">
        <header className="App-header">
          <h1 className="App-title">Restaurants in Cairo</h1>
          <i className="fas fa-bars" onClick={toggle} tabIndex='0' aria-label='menu'></i>
        </header>

        <div>
          <List
            location={showPlaces}
            query={this.state.query}
            handleChange={this.handleValueChange}
            onListClick={this.onListClick}
          />
        </div>
        <div id='info'>
          <a href='https://www.facebook.com' target='_blank'><i className="fab fa-facebook-f"></i></a>
          <a href='https://twitter.com' target='_blank'><i className="fab fa-twitter"></i></a>
        </div>
        <div className='map' id='map'>
          <ErrorBoundary>
            <MapDetails
              google={this.props.google}
              location={showPlaces}
              onMarkClick={this.onMarkerClick}
              marker={this.state.activeMarker}
              visible={this.state.showingInfoWindow}
              selectedPlaces={this.state.selectedPlace}
              icon={this.state.markerIcon}
            />
          </ErrorBoundary>
        </div>

      </div>
    );
  }
}

export default App
