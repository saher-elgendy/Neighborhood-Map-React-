import React from 'react'


function Footer(){
   return(
       <footer className='footer'>
        <p>Made by Mohamed Nabil using <a href='https://foursquare.com/'>Foursquare api</a></p>
       </footer>
   )
}

export default Footer