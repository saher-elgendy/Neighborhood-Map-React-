Neighborhood Map Project:

It's a project showing google map of my country and having markers of the famous restaurants in this area and by clicking on the marker shows a window having information of this place it's name and address, and there is a side list of these places on clicking on a list shows the same infowindow on it's marker, there is an input to filter the places.

This project is made by Create-React-App

How to install:
Run npm install in the folder of the project to install the dependencies
Then run npm start to start the local server on localhost:3000

Using service workers:

1- npm run build 
2- serve -s build
3- open in localhost:5000

Code Dependencies:

1- React
2- Escape RegExp special characters
3- google-maps-react package
4- Foursquare api
5- Error Boundary
