import React, { Component } from 'react';
import { Map, Marker, InfoWindow, GoogleApiWrapper } from 'google-maps-react';

class MapDetails extends Component {
    
    render() {
        const googleMap = this.props.google
        
        return (
            <div className='map-container' role='application'>
                <Map
                    google={googleMap}
                    initialCenter={{
                        lat: 30.04442,
                        lng: 31.235712
                    }}
                    style={{
                        height: '95%'
                    }
                    }
                    zoom={10}
                >

                    {this.props.location.map((mark) => {
                        return (
                            
                            <Marker
                                key={mark.id}
                                name={mark.name}
                                title={mark.name}
                                address={mark.location.address}
                                position={{ lat: mark.location.lat, lng: mark.location.lng }}
                                icon={this.props.icon}
                                onClick={this.props.onMarkClick}
                                //Got this idea of animation from stackoverflow:https://stackoverflow.com/questions/51160344/animate-marker-when-click-on-a-list-item-google-maps-react.
                                animation={this.props.marker ?
                                    (mark.name === this.props.marker.title ? '1' : '0') : '0'}
                            />
                            
                        )
                        
                    })}
                    
                    <InfoWindow
                    marker ={this.props.marker}
                    visible ={this.props.visible}
                    >
                    <div>
                    <h1 tabIndex={'0'}>Name:{this.props.selectedPlaces.title}</h1>
                    <h2 tabIndex={'0'}>Address:{this.props.selectedPlaces.address}</h2>
                    </div>
                    </InfoWindow>
                    
                </Map>
                </div>
        )
    }
}

export default GoogleApiWrapper({
    apiKey: 'AIzaSyCmqVCrMbZBTFxVtfCdVAaOgER8a4s1KcQ'
  })(MapDetails)