import React, {Component} from 'react';
import './List.css';
import Footer from './Footer'

class List extends Component{
    render(){
        return(
            <div className='list' id='sidelist'>
            <input type='text'
            className='filter'
            placeholder='Type to Filter'
            value ={this.props.query}
            onChange ={e => {this.props.handleChange(e.target.value)}}
            aria-label ='searchbox'
            tabIndex = '0'
            />
             <ul className='lists'>
                 {this.props.location.map((places, i) => {
                     return(
                     <li
                     key ={i}
                     className ='place'
                     onClick ={() => {this.props.onListClick(places.name)}}
                     tabIndex = '0'
                     role= 'link'
                     aria-label ='itemlink'
                     >
                     {places.name}
                     </li>
                     )
                 })}
             </ul>
             <Footer className='footer'/>
          </div>
        )
    }
}

export default List;